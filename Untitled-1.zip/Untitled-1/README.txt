Thank you for downloading "Untitled-1", the first game by Games Without Names studio!

Downloading Instructions: If you're reading this, then Congradulations! You have successfully
downloaded the game!

Installation Notes: Inside of Untitled-1.zip, there should be three files. The first file is
Untitled-1.jar. This is the game executable, and opening this will run the game. The second
file is this document, README.txt. The third is a folder called assets. This folder contains
all of the game assets, and is necessarry to run the game. Please do not modify anything in
this folder, as it may break the game. If you wish to move Untitled-1.jar, this folder must
be in the same directory as the .jar file to run correctly.

Dependancies: To successfully run the game, your computer must have the Java Development Kit
(JDK) installed. If you have not done so already, go to here: https://www.oracle.com/technetwork/java/javase/downloads/index.html
to install the JDK. If you are using a mac, you are a terrible human being, and must use Maven
to run the game. More information on that to follow.

Thank you again for choosing Untitled-1! From the entire development team, we hope you enjoy!